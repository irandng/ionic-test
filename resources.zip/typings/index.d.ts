/// <reference path="globals/moment/index.d.ts" />
/// <reference path="globals/socket.io-client/index.d.ts" />
