See https://codecanyon.net/licenses/terms/regular for details.

---

## Can
You may sell, modify, and distribute this app as a single product.

## Can't
You may not use this template for multiple for sale products.
You may not sell or incorporate this template as part of a larger template.

---

For multi-use cases, please purchase a version of the template for each separate app, or contact ionic@devin.la for other licensing options.